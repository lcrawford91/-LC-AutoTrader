# LC AutoTrader — Safe Starter

A fresh Android + Vercel dashboard starter. **Paper mode only.** No broker connections, credentials, live orders, or automatic trading.

## Deploy dashboard on Vercel
Import this repository at https://vercel.com/new.
- Framework preset: Other
- Root directory: `web`
- Build command: leave blank
- Output directory: leave blank (Vercel serves the static files)

## Build Android debug APK
Open GitHub Actions → **Build Android APK** → Run workflow (or push to main).
After a successful run, download the `LC-AutoTrader-debug-apk` artifact and extract the APK.
Android app displays the *bundled offline* dashboard, so it works without a Vercel deployment.

## Project layout
- `web/`: Vercel static dashboard
- `android-app/`: native Android WebView wrapper with a bundled copy of the dashboard
- `.github/workflows/build-apk.yml`: Android CI
- `scripts/sync_web.py`: copies dashboard into Android assets

## Security
Live trading is intentionally absent, not merely hidden by a UI toggle.
No API keys, trade execution code, OAuth, broker endpoints, or background automation.
Never add API keys to GitHub or the Android APK. A later broker integration needs a secure server and independent safety review.

## Local build (Linux)
Requires JDK 17, Android SDK (platform 35, build tools), and Gradle 8.9:
`python3 scripts/sync_web.py && cd android-app && gradle assembleDebug`
