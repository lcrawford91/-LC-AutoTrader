plugins { id("com.android.application") }
android {
    namespace = "uk.lcautotrader.starter"
    compileSdk = 35
    defaultConfig {
        applicationId = "uk.lcautotrader.starter"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
