(() => {
  "use strict";
  const key = "lc-autotrader-paper-notes-v1";
  const form = document.querySelector("#journal");
  const entries = document.querySelector("#entries");
  const read = () => { try { const x=JSON.parse(localStorage.getItem(key)||"[]"); return Array.isArray(x)?x:[]; } catch { return []; } };
  const render = () => {
    entries.replaceChildren();
    for (const item of read()) {
      const li=document.createElement("li");
      const heading=document.createElement("strong");
      heading.textContent = `${item.market} · ${item.date}`;
      const p=document.createElement("p"); p.textContent=item.note;
      li.append(heading,p); entries.append(li);
    }
  };
  form.addEventListener("submit", e => {
    e.preventDefault();
    const note=document.querySelector("#note").value.trim();
    if (!note) return;
    const items=read();
    items.unshift({market:document.querySelector("#market").value,note:note.slice(0,500),date:new Date().toLocaleString()});
    try {localStorage.setItem(key,JSON.stringify(items.slice(0,50)));} catch {alert("Storage unavailable");return;}
    form.reset();render();
  });
  document.querySelector("#clear").addEventListener("click",()=>{localStorage.removeItem(key);render();});
  render();
})();