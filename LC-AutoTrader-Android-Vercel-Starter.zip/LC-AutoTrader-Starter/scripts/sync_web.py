from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
source=root/"web"
dest=root/"android-app/app/src/main/assets"
dest.mkdir(parents=True,exist_ok=True)
for name in ("index.html","style.css","app.js"):
    shutil.copy2(source/name,dest/name)
print("Android assets synced.")
