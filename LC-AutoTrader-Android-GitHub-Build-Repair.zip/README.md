# LC AutoTrader Live — source scaffold

This is a planning scaffold, not an installable APK. It adds a native Kotlin/Compose starting structure and a pure domain boundary for risk/execution, while leaving live order submission intentionally unimplemented and disabled.

## Included

- `docs/DEVELOPMENT_ROADMAP.md` — phased delivery, exit gates, known constraints and blockers.
- `docs/BUILD_GUIDE.md` — instructions for building the Android debug APK.
- `app/src/main/kotlin/.../RiskPolicy.kt` — fail-closed order policy outline.
- `app/src/main/kotlin/.../ExecutionGateway.kt` — preview-before-submit adapter contract.
- `app/src/main/kotlin/.../TradingMode.kt` — distinct mode/state model.
- `app/src/main/kotlin/.../MainActivity.kt` — minimal Material 3 dashboard shell with live status clearly disabled.
- `backend/README.md` — trust boundary and server-side execution requirements.
- `backend/learning/README.md` — isolated strategy evaluation and promotion rules.

## Important

No provider credentials, account data, order endpoint implementation, Gradle wrapper, signing config, or APK are included. Do not treat the current Python paper simulator as live trading. Do not put API keys in the Android package. This scaffold cannot place orders.

See `docs/DEVELOPMENT_ROADMAP.md` for risk limits, the unresolved sizing conflict, BTC-floor assumptions and release gates. Live execution remains disabled.
