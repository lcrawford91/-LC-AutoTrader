# Backend trust boundary

The Android client must not hold Coinbase signing secrets or eToro API keys. Use an authenticated HTTPS control API and keep provider credentials in a server-side secret store with minimum scopes, no withdrawal permission, and redacted audit logs.

Before any submit implementation:

1. Re-read venue account state, product status, available cash, increments/minimums, bid/ask, and account-specific fees.
2. Reject stale or missing inputs.
3. Enforce policy and reserve funds atomically.
4. Persist intent and unique idempotency/client ID before the venue request.
5. Call the venue preview endpoint and preserve its response with the audit record.
6. Only then submit; on timeout reconcile by client ID/order/fills before retrying.
7. Recheck automation enabled and kill-switch immediately before every strategy order.

The phone app is a control/monitoring client. A foreground service alone is not a reliable 24/7 execution host; unattended automation needs a monitored always-on service and documented recovery behavior.
