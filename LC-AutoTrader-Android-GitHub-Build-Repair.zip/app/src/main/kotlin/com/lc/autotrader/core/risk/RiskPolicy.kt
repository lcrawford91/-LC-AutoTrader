package com.lc.autotrader.core.risk

import java.math.BigDecimal

/** Fail-closed policy outline. Enforcement belongs in the authenticated execution service. */
data class RiskPolicy(
    val maxOrderGbp: BigDecimal = BigDecimal("10.00"),
    val dailyLossLimitGbp: BigDecimal = BigDecimal("3.00"),
    val btcMinimumRetained: BigDecimal = BigDecimal("0.00067657"),
    val spotOnly: Boolean = true,
    val liveOrdersEnabled: Boolean = false,
) {
    fun checkBuy(
        notionalGbp: BigDecimal,
        estimatedFeeGbp: BigDecimal,
        freeCashGbp: BigDecimal,
        dataFresh: Boolean,
    ): String? = when {
        !spotOnly -> "Unsupported risk configuration"
        !liveOrdersEnabled -> "Live order submission is disabled"
        !dataFresh -> "Quote or account data is stale"
        notionalGbp <= BigDecimal.ZERO -> "Order size must be positive"
        notionalGbp + estimatedFeeGbp > maxOrderGbp -> "Order exceeds the active GBP cap including fees"
        notionalGbp + estimatedFeeGbp > freeCashGbp -> "Insufficient free cash"
        else -> null
    }

    fun checkBtcSell(
        currentBtc: BigDecimal,
        requestedBtc: BigDecimal,
        dataFresh: Boolean,
    ): String? = when {
        !liveOrdersEnabled -> "Live order submission is disabled"
        !dataFresh -> "Account data is stale"
        requestedBtc <= BigDecimal.ZERO -> "Sell size must be positive"
        currentBtc - requestedBtc < btcMinimumRetained -> "Would breach protected BTC floor"
        else -> null
    }
}
