package com.lc.autotrader.core.execution

import java.math.BigDecimal

/** Venue-neutral contracts. Implementations must call the official venue preview before submit. */
data class OrderIntent(
    val venue: String,
    val productId: String,
    val side: Side,
    val orderType: OrderType,
    val size: BigDecimal,
    val clientOrderId: String,
)

enum class Side { BUY, SELL }
enum class OrderType { MARKET, LIMIT, STOP_LIMIT, BRACKET }

data class OrderPreview(
    val accepted: Boolean,
    val estimatedFee: BigDecimal?,
    val estimatedNotional: BigDecimal?,
    val riskDecision: String,
    val previewReference: String?,
)

interface ExecutionGateway {
    suspend fun preview(intent: OrderIntent): OrderPreview

    /** Must reject unless preview is accepted, fresh, and bound to this exact intent. */
    suspend fun submit(intent: OrderIntent, preview: OrderPreview): String

    suspend fun reconcile(clientOrderId: String): String
}
