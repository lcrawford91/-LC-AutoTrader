package com.lc.autotrader

import com.lc.autotrader.core.risk.RiskPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.math.BigDecimal

class RiskPolicyTest {
    private fun gbp(value: String) = BigDecimal(value)

    @Test fun liveBuyIsDisabledByDefault() {
        val reason = RiskPolicy().checkBuy(gbp("5"), gbp("0.10"), gbp("20"), true)
        assertEquals("Live order submission is disabled", reason)
    }

    @Test fun liveBtcSellIsDisabledByDefault() {
        val reason = RiskPolicy().checkBtcSell(gbp("1"), gbp("0.1"), true)
        assertEquals("Live order submission is disabled", reason)
    }

    // Enable only the policy object in isolated unit tests; the APK build flag stays false.
    private val policy = RiskPolicy(liveOrdersEnabled = true)

    @Test fun rejectsStaleBuyData() {
        assertEquals("Quote or account data is stale", policy.checkBuy(gbp("5"), gbp("0"), gbp("20"), false))
    }

    @Test fun rejectsZeroSizeBuy() {
        assertEquals("Order size must be positive", policy.checkBuy(gbp("0"), gbp("0"), gbp("20"), true))
    }

    @Test fun rejectsBuyAboveCapIncludingFees() {
        assertEquals("Order exceeds the active GBP cap including fees", policy.checkBuy(gbp("10"), gbp("0.01"), gbp("20"), true))
    }

    @Test fun rejectsBuyWithInsufficientCash() {
        assertEquals("Insufficient free cash", policy.checkBuy(gbp("5"), gbp("0.20"), gbp("5"), true))
    }

    @Test fun acceptsBuyWithinPolicyLimits() {
        assertNull(policy.checkBuy(gbp("5"), gbp("0.20"), gbp("20"), true))
    }

    @Test fun rejectsBtcSellBelowProtectedFloor() {
        assertEquals("Would breach protected BTC floor", policy.checkBtcSell(gbp("0.001"), gbp("0.0005"), true))
    }

    @Test fun rejectsStaleBtcBalance() {
        assertEquals("Account data is stale", policy.checkBtcSell(gbp("1"), gbp("0.1"), false))
    }

    @Test fun rejectsZeroBtcSell() {
        assertEquals("Sell size must be positive", policy.checkBtcSell(gbp("1"), gbp("0"), true))
    }

    @Test fun acceptsBtcSellThatPreservesFloor() {
        assertNull(policy.checkBtcSell(gbp("0.001"), gbp("0.0001"), true))
    }
}
